import React, { useState, useEffect } from "react";
import { Container, Button } from "react-bootstrap";
import { useCookies } from "react-cookie";
import { useNavigate } from "react-router-dom";
import Menu from "./Menu";
import NewChat from "./NewChat";
import InputChat from "./InputChat";

function Chat({userData}) {

  const [connectedUser, setConnectedUser] = useState("");

  const userData = () => {
    
  }


  const [messages, setMessages] = useState([]);
  const [cookies, setCookie, removeCookie] = useCookies(["token"]);

  const navigate = useNavigate();

  useEffect(() => {
    checkToken();
  }, []);

  const checkToken = () => {
    if (!cookies.token) {
      navigate("/");
    }
  };

  return (
    <>
      <Menu />

      <Container fluid>
        <div className="chat-main">
          <div className="chat-container mt-4 d-flex flex-row justify-content-center">
            <div className="user-chats col-2 bg-primary bg-opacity-75 p-3 me-2 border-1 rounded-5 d-flex flex-column">
              <NewChat />
              <div className="registered-chats mt-3">
                <ul>{/* Render chat names here */}</ul>
              </div>
            </div>

            <div className="user-current-chat col-9 bg-primary bg-opacity-75 p-3 ms-2 border-1 rounded-5 d-flex flex-column justify-content-between">
              <div className="chat-current-msgs">Test test test</div>
              <InputChat />
            </div>
          </div>
        </div>
      </Container>
    </>
  );
}

export default Chat;
